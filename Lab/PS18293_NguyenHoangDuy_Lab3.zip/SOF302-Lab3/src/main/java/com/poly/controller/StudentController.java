package com.poly.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.poly.model.Genre;
import com.poly.model.Student;

@Controller
public class StudentController {
	@Autowired
	ServletContext app;

	private static List<Student> std = new ArrayList<Student>();

	@GetMapping("/index")
	public String form(@ModelAttribute("student") Student student) {
		return "student";
	}

	@ModelAttribute("genders")
	public List<Genre> getGenders() {
		List<Genre> genres = new ArrayList<>();
		genres.add(new Genre(true, "Male"));
		genres.add(new Genre(false, "Female"));
		return genres;
	}

	@ModelAttribute("faculties")
	public List<String> getFaculties() {
		return Arrays.asList("CNTT", "DLNHKS", "QTDN");
	}

	@ModelAttribute("hobbies")
	public List<String> getHobbies() {
		List<String> hobbies = new ArrayList<>();
		hobbies.add("Travelling");
		hobbies.add("Music");
		hobbies.add("Food");
		hobbies.add("Other");
		return hobbies;
	}

	@PostMapping("/index/save")
	public String save(ModelMap model, @Validated @ModelAttribute("student") Student student, BindingResult errors) {
		if (errors.hasErrors()) {
			model.addAttribute("message", "Vui lòng sửa các lỗi dưới đây!");
		} else {
			model.addAttribute("message", "Bạn đã nhập đúng!");
			std.add(student);
			model.addAttribute("students", std);
		}
		return "student";
	}

}
