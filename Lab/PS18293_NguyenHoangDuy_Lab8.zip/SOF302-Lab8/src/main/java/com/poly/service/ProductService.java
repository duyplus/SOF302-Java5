package com.poly.service;

import org.springframework.data.domain.Page;

import com.poly.entity.Product;

public interface ProductService {

	Page<Product> findAll(Integer page, Integer limit);

	Page<Product> findByField(Integer page, Integer limit, String field, String name);

}