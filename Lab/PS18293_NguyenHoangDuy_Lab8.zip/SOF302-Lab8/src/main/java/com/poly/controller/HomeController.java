package com.poly.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.poly.dao.CategoryDAO;
import com.poly.dao.ProductDAO;
import com.poly.entity.Product;
import com.poly.service.ProductService;
import com.poly.service.SessionService;

@Controller
public class HomeController {

	@Autowired
	ProductDAO pdao;

	@Autowired
	CategoryDAO cdao;

	@Autowired
	ProductService productService;

	@Autowired
	SessionService session;

	Boolean count;

	@RequestMapping("/index")
	public String index(@RequestParam("p") Optional<Integer> p, Model model) {
		model.addAttribute("category", cdao.findAll());
		model.addAttribute("product", pdao.findAll(PageRequest.of(p.orElse(0), 6)));
		model.addAttribute("categoryid1002", pdao.findByCategoryId("1002"));
		model.addAttribute("categoryid1007", pdao.findByCategoryId("1007"));
		return "home/index";
	}

	@RequestMapping("/shop")
	public String shop(Model model, @RequestParam(name = "page") Optional<Integer> p,
			@RequestParam(name = "field", defaultValue = "") String field) {
		if (field.equals("")) {
			model.addAttribute("page", pdao.findAll(PageRequest.of(p.orElse(0), 9)));
		} else {
			model.addAttribute("page", productService.findByField(p.orElse(0), 9, field, ""));
		}
		return "home/shop";
	}

	@RequestMapping("/product/{id}")
	public String product(Model model, @PathVariable("id") Integer id) {
		Product item = pdao.findById(id).get();
		model.addAttribute("item", item);
		return "home/product";
	}

	@RequestMapping("/shop/search")
	public String search(Model model, @RequestParam("keywords") Optional<String> kw,
			@RequestParam("p") Optional<Integer> p) {
		String keywords = kw.orElse(session.get("keywords", ""));
		session.set("keywords", keywords);
		Pageable pageable = PageRequest.of(p.orElse(0), 5);
		Page<Product> page = pdao.findByKeywords("%" + keywords + "%", pageable);
		model.addAttribute("page", page);
		return "home/shop";
	}

	@RequestMapping("/about")
	public String about() {
		return "home/about";
	}

	@RequestMapping("/contact")
	public String contact() {
		return "home/contact";
	}
}