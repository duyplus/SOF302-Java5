package com.poly.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.poly.dao.ProductDAO;
import com.poly.entity.Product;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductDAO dao;

	Boolean count = true;

	@Override
	public Page<Product> findAll(Integer page, Integer limit) {
		Pageable pageable = PageRequest.of(page, limit);
		return dao.findAll(pageable);
	}

	@Override
	public Page<Product> findByField(Integer page, Integer limit, String field, String name) {
		if (!name.isEmpty()) {
			Pageable pageable = PageRequest.of(page, limit, Sort.by(Direction.ASC, "id"));
			return dao.findAllByNameLike(name, pageable);
		} else if (field.equals("")) {
			Pageable pageable = PageRequest.of(page, limit);
			return dao.findAll(pageable);
		} else {
			if (count) {
				count = false;
				Pageable pageable = PageRequest.of(page, limit, Sort.by(Direction.ASC, field));
				return dao.findAll(pageable);
			} else {
				count = true;
				Pageable pageable = PageRequest.of(page, limit, Sort.by(Direction.DESC, field));
				return dao.findAll(pageable);
			}
		}
	}

}