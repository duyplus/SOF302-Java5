package com.poly.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Bai1OkController {
	@GetMapping("/bai1")
	public String lab2Bai1(Model model) {
		model.addAttribute("ketqua", "m0");
		System.out.println("m0");
		return "bai1";
	}

	@PostMapping("/bai1/ok")
	public String m1(Model model) {
		model.addAttribute("ketqua", "m1");
		System.out.println("m1");
		return "bai1";
	}

	@GetMapping("/bai1/ok")
	public String m2(Model model) {
		model.addAttribute("ketqua", "m2");
		System.out.println("m2");
		return "bai1";
	}

	@PostMapping("/bai1/okx")
	public String m3(Model model, @RequestParam("x") String x) {
		System.out.println("x = " + x);
		model.addAttribute("ketqua", "m3");
		System.out.println("m3");
		return "bai1";
	}
}
