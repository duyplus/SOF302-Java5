package com.poly.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.poly.model.Product;

@Controller
public class Bai4ProductController {
	public static List<Product> list = new ArrayList<>();

	@GetMapping("/bai4")
	public String bai4Page() {
		Product prod = new Product();
		prod.setName("iPhone 30");
		prod.setPrice(5000.0);
		list.add(prod);
		return "bai4";
	}

	@PostMapping("/bai4/save")
	public String bai4Save(Product prod, Model model) {
		model.addAttribute("product", prod);
		list.add(prod);
		return "bai4";
	}

	@ModelAttribute("getItems")
	public List<Product> getItems() {
		return list;
	}
}
