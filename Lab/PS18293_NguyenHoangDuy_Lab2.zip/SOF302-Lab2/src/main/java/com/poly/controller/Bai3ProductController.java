package com.poly.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.poly.model.Product;

@Controller
public class Bai3ProductController {
	@GetMapping("/bai3")
	public String bai3Page() {
		return "bai3";
	}

	@PostMapping("/bai3/save")
	public String bai3Save(Product product, Model model) {
		model.addAttribute("product", product);
		return "bai3";
	}
}
