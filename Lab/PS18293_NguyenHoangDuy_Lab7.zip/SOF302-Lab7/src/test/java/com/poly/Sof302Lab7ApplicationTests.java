package com.poly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sof302Lab7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
