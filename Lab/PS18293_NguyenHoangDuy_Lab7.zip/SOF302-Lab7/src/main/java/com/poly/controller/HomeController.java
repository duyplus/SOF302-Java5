package com.poly.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.poly.dao.CategoryDAO;
import com.poly.entity.Category;

@Controller
public class HomeController {

	@Autowired
	CategoryDAO dao;

	@RequestMapping("/home/index")
	public String index(Model model) {
		model.addAttribute("item", new Category());
		model.addAttribute("items", dao.findAll());
		return "home/index";
	}
}
