package com.poly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sof302Lab6Application {

	public static void main(String[] args) {
		SpringApplication.run(Sof302Lab6Application.class, args);
	}

}
