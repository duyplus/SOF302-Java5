package com.poly.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.poly.entity.Report;
import com.poly.dao.ProductDAO;
import com.poly.service.SessionService;

@Controller
public class Bai3Controller {
	@Autowired
	ProductDAO dao;

	@Autowired
	SessionService session;

	@RequestMapping("/bai3")
	public String inventory(Model model) {
		List<Report> items = dao.getInventoryByCategory();
		model.addAttribute("items", items);
		return "bai3";
	}
}
