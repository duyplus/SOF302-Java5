package com.poly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sof302Lab6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
