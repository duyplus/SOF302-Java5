package com.poly.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.poly.model.User;

@Controller
public class UserController {
	@Autowired
	HttpServletRequest request;

	@RequestMapping("user")
	public String display() {
		return "user";
	}

	@PostMapping("create")
	public String sendDetail(Model model) {
		String user = request.getParameter("username");
		String pass = request.getParameter("password");
		if (user.equals("ps18293") && pass.equals("123")) {
			model.addAttribute("message", "Đăng nhập thành công!");
			User u = new User(user, pass);
			request.setAttribute("USER", u);
			return "detail";
		} else {
			model.addAttribute("message", "Sai thông tin đăng nhập!");
			return "user";
		}
	}
}
