package com.poly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sof302Lab4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
