package com.poly.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.poly.service.CookieService;
import com.poly.service.ParamService;
import com.poly.service.SessionService;

@Controller
public class LoginController {

	@Autowired
	CookieService cookieService;

	@Autowired
	ParamService paramService;

	@Autowired
	SessionService sessionService;

	@GetMapping("/login")
	public String login1() {
		return "login";
	}

	@GetMapping("/register")
	public String signup() {
		return "register";
	}

	@PostMapping("/login")
	public String login2(Model model) {
		String un = paramService.getString("username", "");
		String pw = paramService.getString("password", "");
		boolean rm = paramService.getBoolean("remember", false);
		if (un.equals("admin") && pw.equals("123")) {
			sessionService.set("username", un);
			if (rm == true) {
				cookieService.add("user", un, 10);
				model.addAttribute("username", un);
				model.addAttribute("message", "Tài khoản đã được lưu!");
				return "redirect:/index";
			} else {
				cookieService.remove("user");
				model.addAttribute("username", "");
				model.addAttribute("message", "Tài khoản không được lưu!");
			}
		} else {
			model.addAttribute("message", "Đăng nhập thất bại!");
		}
		return "login";
	}
}
