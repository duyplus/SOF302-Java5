package com.poly.bean;

import java.util.HashMap;
import java.util.Map;

public class DB {
	public static Map<Integer, Item> items = new HashMap<>();
	static {
		items.put(1, new Item(1, "Heavy Overshirt", 48.99, 0, "1.jpg"));
		items.put(2, new Item(2, "Lexi Cross Body Bag", 24.49, 0, "2.jpg"));
		items.put(3, new Item(3, "Vegan Leather Coat Jacket", 62.99, 0, "3.jpg"));
		items.put(4, new Item(4, "Curved Peak Snapback", 13.99, 0, "4.jpg"));
		items.put(5, new Item(5, "Satin Sleep Short", 20.99, 0, "5.jpg"));
		items.put(6, new Item(6, "Riviera Short Sleeve Shirt", 28.99, 0, "6.jpg"));
		items.put(7, new Item(7, "Active Collab Fleece Short", 34.99, 0, "7.jpg"));
		items.put(8, new Item(8, "Active Wide Leg Pant", 17.49, 0, "8.jpg"));
	}
}
