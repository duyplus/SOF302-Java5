﻿USE master
GO
CREATE DATABASE J5BVM
GO
USE J5BVM
GO
CREATE TABLE Accounts (
	username varchar(50) NOT NULL,
	password varchar(50) NOT NULL,
	fullname nvarchar(50) NOT NULL,
	phone varchar(11) NOT NULL,
	email varchar(50) NOT NULL,
	CONSTRAINT PK_Accounts PRIMARY KEY CLUSTERED (username)
)
GO
INSERT Accounts (username, password, fullname, phone, email) VALUES ('admin', '123', N'Nguyễn Văn A', '0123456789', 'duynhps18293@fpt.edu.vn')
INSERT Accounts (username, password, fullname, phone, email) VALUES ('duyplus', '123', N'Nguyễn Hoàng Duy', '0919993715', 'duyplusdz@gmail.com')