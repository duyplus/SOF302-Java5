package com.poly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sof302BvmApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sof302BvmApplication.class, args);
	}

}
