package com.poly.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.poly.dao.AccountDAO;
import com.poly.entity.Account;

@Controller
public class HomeController {

	@Autowired
	AccountDAO dao;

	@RequestMapping("/list")
	public String home(Model model) {
		model.addAttribute("item", new Account());
		model.addAttribute("items", dao.findAll());
		return "list";
	}

	@GetMapping("list/edit/{id}")
	public String edit(Model model, @PathVariable("id") Integer id) {
		model.addAttribute("item", dao.findById(id).get());
		model.addAttribute("items", dao.findAll());
		return "form";
	}

	@RequestMapping("form")
	public String createform(Model model, Account account) {
		return "form";
	}

	@PostMapping("form/create")
	public String create(Model model, Account account, BindingResult br, RedirectAttributes ra,
			HttpServletResponse response) {
		if (br.hasErrors()) {
			ra.addFlashAttribute("message", "Đã có lỗi!");
		} else {
			dao.save(account);
			ra.addFlashAttribute("message", "Thêm sinh viên mới thành công!");
		}
		return "redirect:/form";
	}

	@GetMapping("list/delete/{id}")
	public String delete(@PathVariable("id") Integer id, Account account, BindingResult br, RedirectAttributes ra) {
		if (br.hasErrors()) {
			ra.addFlashAttribute("message", "Đã có lỗi!");
		} else {
			dao.deleteById(id);
			ra.addFlashAttribute("message", "Xoá sinh viên thành công!");
		}
		return "redirect:/list";
	}
}
