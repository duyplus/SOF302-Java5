$(document).ready(function () {
    $('form').parsley();
});