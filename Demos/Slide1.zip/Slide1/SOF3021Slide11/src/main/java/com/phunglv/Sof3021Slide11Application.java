package com.phunglv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class Sof3021Slide11Application {

	public static void main(String[] args) {
		SpringApplication.run(Sof3021Slide11Application.class, args);
	}

}
