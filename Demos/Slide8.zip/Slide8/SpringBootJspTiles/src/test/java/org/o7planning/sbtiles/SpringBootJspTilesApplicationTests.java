package org.o7planning.sbtiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJspTilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
